# Phase 5 — Notifications

## What's new

- **Unread counts** per project card + in greeting total.
- **Bell tray** in header shows all projects with unread messages; click to jump.
- **Tab title badge** — browser tab shows `(3) Handshake` when unread > 0.
- **Mark as read** automatically when you open a project.
- **Immediate email notifications** on new messages (rate-limited: max 1 email per recipient per project per 5 min).
- **User settings page** at `/settings` — pick email frequency (immediate / daily digest / never), toggle in-app, admins toggle flag alerts.

## Migration (run in Supabase SQL editor FIRST)

```sql
-- Copy the contents of migrations/005_email_log.sql and run.
```

## Install

```
unzip -o csdhandshake-phase5.zip
rm csdhandshake-phase5.zip P5-README.md
npm run build
```

If clean:

```
git add . && git commit -m "Phase 5 — Notifications (unread, bell, emails, prefs)" && git push
```

Then apply Phase 6.

## Not included (Phase 7)

- Daily email digest cron — need to set up Vercel cron, will do later.
- Web push notifications — out of scope for MVP.

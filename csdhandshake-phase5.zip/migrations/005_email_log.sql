-- Phase 5 migration: add email_log table for rate-limiting notifications.
-- Run this in the Supabase SQL editor before deploying Phase 5.

CREATE TABLE IF NOT EXISTS email_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  kind TEXT NOT NULL, -- 'new_message' | 'daily_digest' | 'flag_alert' | 'invitation'
  sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS email_log_recipient_project_kind_idx
  ON email_log (recipient_id, project_id, kind, sent_at DESC);

-- Only service role writes to email_log; no RLS policies needed for user access.
ALTER TABLE email_log ENABLE ROW LEVEL SECURITY;

-- District admins can view email logs (for debugging).
CREATE POLICY email_log_select ON email_log FOR SELECT USING (
  current_user_role() = 'district_admin'
);

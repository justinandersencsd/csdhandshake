# Phase 6 — Admin

## What's new

- **/admin dashboard** with 4 metrics: active projects, partners engaged, messages this week, flags to review. Recent flags list inline.
- **/admin/flags** — unified queue of content filter flags + user reports with Dismiss / Escalate actions.
- **/admin/projects** — all projects table with status filter (school-scoped for school admins).
- **/admin/users** — user list with search, role filter, role change (district admin), deactivate/reactivate.
- **/admin/audit** — audit log viewer with category tabs + user filter, last 200 events.
- **Admin sidebar nav** added across admin pages.
- **"Admin" link** in header visible to school/district admins.

## School admin vs district admin

- **School admin**: sees only their school's projects, users, events. Cannot change user roles or deactivate users.
- **District admin**: sees everything. Can change roles and deactivate users across all schools.

## Install

```
unzip -o csdhandshake-phase6.zip
rm csdhandshake-phase6.zip P6-README.md
npm run build
```

If clean:

```
git add . && git commit -m "Phase 6 — Admin dashboard, flag queue, users, audit log" && git push
```

## Test it

After deploy, make sure your Justin account's role is back to `district_admin`:

```sql
UPDATE users
SET role = 'district_admin', school_id = NULL
WHERE email = 'justin.andersen@canyonsdistrict.org';
```

Visit `/admin` — you should see the dashboard with metrics and the nav sidebar.

## Not in Phase 6 (deferred)

- **CSV export of audit log** — planned for Phase 7.
- **Per-school-admin invitation flow** from admin pages — reuse existing /admin/invite.
- **Date range filter on audit** — can add later.

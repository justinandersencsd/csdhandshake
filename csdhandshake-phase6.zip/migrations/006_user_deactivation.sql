-- Phase 6 migration: add deactivated_at column to users for admin deactivation.
-- Safe to run even if column already exists.
-- Run this in the Supabase SQL editor before deploying Phase 6.

ALTER TABLE users ADD COLUMN IF NOT EXISTS deactivated_at TIMESTAMPTZ;

-- Optional: ensure login check can use this (not currently wired — deactivated_at
-- just flags the user; actual login blocking can be added later).
